function submitDetails(){
  alert("Your details submitted successfully!");
}
