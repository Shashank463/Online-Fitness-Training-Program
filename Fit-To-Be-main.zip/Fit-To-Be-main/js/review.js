function star( rate ){

	if ( rate == "btn1"){
		document.getElementById('r1').src="../images/4.jpg";
	}

	if ( rate == "btn2"){
		document.getElementById('r2').src="../images/3.png";
	}

	if ( rate == "btn3"){
		document.getElementById('r3').src="../images/4.jpg";
	}

	if ( rate == "btn4"){
		document.getElementById('r4').src="../images/5.jpg";
	}

	if ( rate == "btn5"){
		document.getElementById('r5').src="../images/3.png";
	}

}


