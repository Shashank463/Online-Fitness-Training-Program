document.getElementById("btn1").addEventListener( "click", redirectToPayment );
document.getElementById("btn2").addEventListener( "click", redirectToPayment );
document.getElementById("btn3").addEventListener( "click", redirectToPayment );
document.getElementById("btn4").addEventListener( "click", redirectToPayment );
document.getElementById("btn5").addEventListener( "click", redirectToPayment );
document.getElementById("btn6").addEventListener( "click", redirectToPayment );
document.getElementById("btn7").addEventListener( "click", redirectToPayment );
document.getElementById("btn8").addEventListener( "click", redirectToPayment );
document.getElementById("btn9").addEventListener( "click", redirectToPayment );

function redirectToPayment() {
location.replace("payment.php")
}