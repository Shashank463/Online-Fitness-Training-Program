<footer>
        <div class="footer" >
            <div>
                <p class="copyRSing">Copyright &#169; 2020 - FIT TO BE - All Rights Reserved</p>
            </div>  
            <div class="SocialLogos">
                <a href="https://facebook.com" ><img src="../images/FBLogo.png" alt="Facebook"></a> 
                <a href="https://instagram.com" ><img src="../images/InstaLogo.png" alt="Instagram"></a> 
                <a href="https://twitter.com" ><img src="../images/TwitterLogo.png" alt="Twitter"></a> 
                <a href="https://youtube.com" ><img src="../images/youtube.png" alt="Youtube"></a>  
            </div>
        </div>
    </footer>